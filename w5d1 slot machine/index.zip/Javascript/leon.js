//Leon's HTML: created three spans for each reel. spanids = reel1, reel2 and reel3. gave button for min and max bet. ids = minBet, maxBet
var total = 100;

document.getElementById('minBet').addEventListener("click", function(){
/*used alert("works") here and ran it to test that this was working before any other code was done.*/
//set reel values
var reel1 = randomReel(),
reel2 = randomReel()
reel3 = randomReel();
//use conditional to update total value
if( checkMatch(reel1, reel2, reel3) ){
  total = total + 25;
}else{
  total = total - 1;
}
//update dom with new total
document.getElementById('total').innerHTML = total;
}); //PRACTICE THIS SYNTAX
document.getElementById('maxBet').addEventListener("click", function(){
  var reel1 = randomReel(),
  reel2 = randomReel()
  reel3 = randomReel();
  //use conditional to update total value
  if( checkMatch(reel1, reel2, reel3) ){
    total = total + 250;
  }else{
    total = total - 25;
  }
  //update dom with new total
  document.getElementById('total').innerHTML = total;
})

//While the array method works, we haven't gone over it. Do what you know. i should have done the method from RPS for the randomization.

//creating function for the randomization since it's something that will have to be done multiple times in different places.
function randomReel(){
  //1 out of 5 being selected. return the value.
  var choice = Math.random()
  if (choice <= .2){
    choice = "cherry"
  }else if (choice<=.4){
    choice = "bar"
  }else if (choice<=.6){
    choice = "seven"
  }else if(choice<=.8){
    choice = "bell"
  }else{
    choice = "moneyBag"
  } /*after typing this out, we hid the conditional in the initial function and console logged the variables to make sure they're being randomly generated */
  //Could add in one last conditional that does .9-.98 for example with jackpot.
}

function checkmatch(reel1, reel2, reel3){
  //compare reels to find if user is winner
  //return true or false.
  if(reel1===reel2 && reel1===reel3){
    return true
  }else{
    return false
  }
}
